﻿namespace Zenseless.HLGL
{
	/// <summary>
	/// 
	/// </summary>
	public interface IState
	{
	}
}
