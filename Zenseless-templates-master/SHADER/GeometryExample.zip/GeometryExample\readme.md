1. Generate individual sizes for each point on the cpu and use them in your shader
1. Generate individual colors for each point on the cpu and use them in your shader
1. Vary parameters like size and color over time
1. Let the points bounce off the window borders (could use repeated tent = abs(mod(x + 3, 4) - 2) - 1)
