1. Load your own [obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file) file (only triangulated, single mesh models)
1. Load and render a textured model
