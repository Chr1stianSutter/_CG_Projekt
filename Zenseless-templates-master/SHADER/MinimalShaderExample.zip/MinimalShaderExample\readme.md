1. compile/run shader
1. Load shader from file
1. Set one fixed color
