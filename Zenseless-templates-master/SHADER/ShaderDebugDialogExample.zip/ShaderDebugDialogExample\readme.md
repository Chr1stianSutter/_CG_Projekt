1. Look at ShaderFileWatcher for on-the-fly editing

