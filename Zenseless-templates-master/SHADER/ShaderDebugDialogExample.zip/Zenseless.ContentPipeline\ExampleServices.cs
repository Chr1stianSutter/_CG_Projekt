﻿using System;
using Zenseless.Base;

namespace Zenseless.ExampleFramework
{
	internal class ExampleServices //TODO: instead of ExampleWindow
	{
		public ExampleServices()
		{
			//serviceLocator.RegisterService();
		}

		private ServiceLocator serviceLocator = new ServiceLocator();
	}
}
